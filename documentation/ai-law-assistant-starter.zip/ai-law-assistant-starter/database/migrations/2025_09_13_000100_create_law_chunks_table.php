<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('law_chunks', function (Blueprint $table) {
            $table->uuid('id')->primary();
            $table->string('tenant_id');
            $table->string('source');
            $table->string('title');
            $table->string('citation');
            $table->text('url');
            $table->longText('text');
            $table->string('embedding_model')->default('text-embedding-3-small');
            // Optional metadata for future ingest/idempotency
            $table->string('law_id')->nullable();
            $table->string('text_sha256')->nullable();
            $table->date('valid_from')->nullable();
            $table->date('valid_to')->nullable();
            $table->timestamps();
        });

        DB::statement("ALTER TABLE law_chunks ADD COLUMN embedding vector(1536);");
        DB::statement("CREATE INDEX law_chunks_fts_idx ON law_chunks USING GIN (to_tsvector('simple', text));");
        DB::statement("CREATE INDEX IF NOT EXISTS law_chunks_law_id_idx ON law_chunks (law_id);");
        DB::statement("CREATE INDEX IF NOT EXISTS law_chunks_text_sha_idx ON law_chunks (text_sha256);");
    }

    public function down(): void
    {
        Schema::dropIfExists('law_chunks');
    }
};
