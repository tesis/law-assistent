<?php
use Illuminate\Support\Facades\Route;

Route::get('/ask-demo', fn() => view('ask'));
