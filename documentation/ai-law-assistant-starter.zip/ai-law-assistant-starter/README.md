# AI Law Assistant — Laravel 12 + PostgreSQL + pgvector (MVP)

This starter packs the clean files you need to spin up a minimal RAG-based **AI legal assistant**.

## What’s inside
- **pgvector** migration
- **LawChunk** model
- **RagService** (embeddings, search, answer)
- **AskController** and `/api/ask`
- **Seed & repair** console commands
- **(Optional) PISRS API client** for future ingest
- **Simple demo page** at `/ask-demo`

## Quick start

1) Start PostgreSQL (>= 15). Example for Docker:
```yaml
services:
  db:
    image: postgres:15
    environment:
      POSTGRES_USER: app
      POSTGRES_PASSWORD: app
      POSTGRES_DB: appdb
    ports: ["5432:5432"]
    volumes: [dbdata:/var/lib/postgresql/data]
volumes:
  dbdata:
```

2) Configure your Laravel `.env`:
```
DB_CONNECTION=pgsql
DB_HOST=127.0.0.1
DB_PORT=5432
DB_DATABASE=appdb
DB_USERNAME=app
DB_PASSWORD=app

OPENAI_API_KEY=sk-...
```

3) Copy the files in this package into the **root of your Laravel project**, preserving folders.

4) Run migrations & (optional) seed:
```bash
php artisan migrate
php artisan law:seed
```

5) Start dev server and test the endpoint:
```bash
php artisan serve
curl -X POST http://127.0.0.1:8000/api/ask   -H "Content-Type: application/json"   -d '{"q":"Kateri člen ureja odpoved pogodbe o zaposlitvi?", "mode":"hybrid"}'
```

6) Try the simple UI:
```
http://localhost:8000/ask-demo
```

## Notes
- `RagService` uses **parameterized pgvector** queries (`?::vector`), avoiding SQL literal pitfalls.
- If embeddings fail (quota, key), chunks are inserted with `embedding = NULL`. Use **LawRepairEmbeddings** to backfill later.
- Add **IVFFLAT** index after bulk ingest:
```sql
CREATE INDEX law_chunks_vec_idx ON law_chunks
USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
```

## Security
Protect `/api/ask` with `auth:sanctum` in production and add per-tenant quotas.
