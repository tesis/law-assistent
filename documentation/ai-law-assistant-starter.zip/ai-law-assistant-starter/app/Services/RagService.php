<?php
namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class RagService
{
    /** Create embedding vector for text (OpenAI) */
    public function embed(string $text): array
    {
        $resp = Http::withToken(env('OPENAI_API_KEY'))->post(
            'https://api.openai.com/v1/embeddings', [
                'model' => 'text-embedding-3-small',
                'input' => mb_substr($text, 0, 8000)
            ]
        );

        if (!$resp->ok()) {
            \Log::error('Embedding API error', ['status'=>$resp->status(), 'body'=>$resp->json()]);
            return [];
        }

        $data = $resp->json();
        $vec = $data['data'][0]['embedding'] ?? [];

        if (!is_array($vec) || count($vec) < 1) {
            \Log::error('Empty embedding returned', ['data'=>$data]);
            return [];
        }

        return $vec;
    }

    /** Insert chunk; embedding may be NULL when unavailable */
    public function upsertChunk(array $payload): void
    {
        $vec = $this->embed($payload['text']);

        DB::table('law_chunks')->insert([
            'id' => $payload['id'] ?? (string) \Str::uuid(),
            'tenant_id' => $payload['tenant_id'] ?? 'PUBLIC',
            'source' => $payload['source'],
            'title' => $payload['title'],
            'citation' => $payload['citation'],
            'url' => $payload['url'],
            'text' => $payload['text'],
            'embedding_model' => 'text-embedding-3-small',
            'embedding' => empty($vec) ? null : sprintf('[%s]', implode(',', $vec)),
            'law_id' => $payload['law_id'] ?? null,
            'text_sha256' => $payload['text_sha256'] ?? null,
            'valid_from' => $payload['valid_from'] ?? null,
            'valid_to' => $payload['valid_to'] ?? null,
            'created_at' => now(),
            'updated_at' => now(),
        ]);
    }

    /** Pure vector search using pgvector (parameterized) */
    public function vectorSearch(string $q, string $tenantId, int $k = 6): array
    {
        $qVec = $this->embed($q);
        if (empty($qVec)) return [];

        $qVecStr = '['.implode(',', $qVec).']';

        $rows = DB::select(
            """
            SELECT id, source, title, citation, url, text,
                   1 - (embedding <=> ?::vector) AS score
            FROM law_chunks
            WHERE tenant_id IN ('PUBLIC', ?)
              AND embedding IS NOT NULL
            ORDER BY embedding <=> ?::vector ASC
            LIMIT {$k}
            """,
            [$qVecStr, $tenantId, $qVecStr]
        );

        return array_map(fn($r)=>(array)$r, $rows);
    }

    /** Hybrid: BM25 candidate set -> vector re-rank (parameterized) */
    public function hybridSearch(string $q, string $tenantId, int $k = 6, int $bm25N = 100): array
    {
        $bm25 = DB::select(
            """
            SELECT id, ts_rank(to_tsvector('simple', text), plainto_tsquery('simple', ?)) AS r
            FROM law_chunks
            WHERE tenant_id IN ('PUBLIC', ?)
              AND to_tsvector('simple', text) @@ plainto_tsquery('simple', ?)
            ORDER BY r DESC
            LIMIT {$bm25N}
            """,
            [$q, $tenantId, $q]
        );

        if (!$bm25) return [];

        $ids = implode("','", array_map(fn($x)=>$x->id, $bm25));

        $qVec = $this->embed($q);
        if (empty($qVec)) return [];

        $qVecStr = '['.implode(',', $qVec).']';

        $rows = DB::select(
            """
            SELECT id, source, title, citation, url, text,
                   1 - (embedding <=> ?::vector) AS score
            FROM law_chunks
            WHERE id IN ('{$ids}') AND embedding IS NOT NULL
            ORDER BY embedding <=> ?::vector ASC
            LIMIT {$k}
            """, [$qVecStr, $qVecStr]
        );

        return array_map(fn($r)=>(array)$r, $rows);
    }

    /** Compose final answer from chunks via Chat Completions */
    public function answer(string $q, array $chunks): string
    {
        $context = collect($chunks)->map(fn($c)=>
            "[{$c['source']}] {$c['title']} | {$c['citation']} | {$c['url']}\n{$c['text']}"
        )->join("\n---\n");

        $messages = [
          ['role'=>'system','content'=>"Odgovarjaj IZKLJUČNO na podlagi spodnjih virov. NAVAJAJ člene/CELEX/opr. št. in URL. Če ni dovolj besedila, to jasno povej."],
          ['role'=>'user','content'=>"VIRI:\n{$context}\n\nVPRAŠANJE: {$q}"]
        ];

        $resp = Http::withToken(env('OPENAI_API_KEY'))->post(
            'https://api.openai.com/v1/chat/completions', [
                'model' => 'gpt-4o-mini',
                'messages' => $messages,
                'temperature' => 0.2
            ]
        )->json();

        return $resp['choices'][0]['message']['content'] ?? 'Ne morem zanesljivo odgovoriti.';
    }
}
