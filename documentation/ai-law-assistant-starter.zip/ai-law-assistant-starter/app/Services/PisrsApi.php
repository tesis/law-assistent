<?php
namespace App\Services;

use Illuminate\Support\Facades\Http;

class PisrsApi
{
    public function __construct(
        private readonly string $base = 'https://pisrs.si' // TODO: verify via Swagger
    ) {}

    public function getAct(string $id): array
    {
        $res = Http::get($this->base.'/api/predpisi/'.$id);
        $res->throw();
        return $res->json();
    }

    public function getArticles(string $id): array
    {
        $res = Http::get($this->base.'/api/predpisi/'.$id.'/cleni');
        $res->throw();
        return $res->json();
    }
}
